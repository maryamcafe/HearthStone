package game;

import java.util.List;

public interface State {

     void run(List<Boolean> running);

}
