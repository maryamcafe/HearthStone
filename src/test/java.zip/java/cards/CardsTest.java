package cards;

import cards.CardConstants.*;

import java.util.List;

public class CardsTest {
    public static void main(String[] args) {
    }
}
